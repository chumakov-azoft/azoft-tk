self.__precacheManifest = [
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "98807551bbbd37a2daef",
    "url": "/js/chunk-vendors.da707615.js"
  },
  {
    "revision": "61606904f13644e1a08d",
    "url": "/js/app.5dd25de1.js"
  },
  {
    "revision": "5c41f14245a5284dd9e41241f0489321",
    "url": "/index.html"
  },
  {
    "revision": "98807551bbbd37a2daef",
    "url": "/css/chunk-vendors.af1298c6.css"
  },
  {
    "revision": "61606904f13644e1a08d",
    "url": "/css/app.ca0fa775.css"
  },
  {
    "revision": "738a06433e1b2a1355fbf51200a7e9ec",
    "url": "/CNAME"
  }
];